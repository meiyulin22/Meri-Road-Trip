# Red panda entrance identity

The existing Meri head-turn character is authoritative. Use the decoded center
cell source at column 8, row 8: vertical-08.mp4, native frame 48 (zero based),
24 fps. Preserve the plush rust-orange/cream fur, round brown eyes and catchlights,
closed tiny smile, dark paws, ears, camera, size and light. No full body redesign.
The invisible contact line belongs to the page; no surface may be generated.
The last state is intentionally empty alpha because the subject is fully hidden.
