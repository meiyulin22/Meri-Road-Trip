# Red panda identity

K0-front-alpha.png is the approved half-body identity reference, not the standing mascot.
One rust-orange red panda, cream-white ear rims, eyebrows, cheek markings and muzzle.
Warm brown irises, black pupils, small studio catchlights and visible white sclera.
Dark brown nose and front paws, tiny closed smile. The paws and shoulders stay fixed.
Head may yaw/pitch naturally without showing the back of the head or changing identity.
Preserve soft detailed plush fur, scale, locked camera, lighting and square framing.
No hats, props, table, chat box, text, motion blur or extra limbs.
Generated keyframes must have true alpha. Green video inputs are separate deterministic copies.
